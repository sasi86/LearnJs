var greeting = 'Hello world greet5'

function greet() {
	console.log(greeting);
}

module.exports = {
	greet
}