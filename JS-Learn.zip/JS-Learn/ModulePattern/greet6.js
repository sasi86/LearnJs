export default function greet(params) {
    console.log(params);
}