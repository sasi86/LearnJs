const a = require('./module-example/folder')
console.log(a)
var greet = require('./greet1');
greet();

var greet2 = require('./greet2').greet;
greet2();


//Singleton PatternExample
var greet3 = require('./greet3');
greet3.greet();
greet3.greeting = 'Changed hello world!';

var greet3b = require('./greet3');
greet3b.greet();

//Prototype pattern
var Greet4 = require('./greet4');
var grtr = new Greet4();
grtr.greet();

var greet5 = require('./greet5').greet;
greet5();


//ES6 style add type : module in package.json
// import greet6 from './greet6.js'
// console.log(greet6('Hi'));
