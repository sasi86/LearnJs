module.exports = {
    file1 : "file1"
}