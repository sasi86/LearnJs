const file1 =require('./file1').file1
const file2 = require('./file2').file2

module.exports = {
    file1,
    file2
}