var arr = [10,20,30,40]
console.log(arr.push(50))
console.log(arr.pop())

console.log(arr.shift())
console.log(arr)
