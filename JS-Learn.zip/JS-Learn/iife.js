(function(params) {
    console.log('Hello');
})();