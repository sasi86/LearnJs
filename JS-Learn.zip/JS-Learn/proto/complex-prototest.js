function EE(){
    this.on = function on() {
        return 'on';
    }
}

function Greet() {
    //like a super call in java, if you avoid props of EE wont be available to Greet
    EE.call(this)
    this.greeting = 'Hello World!'
}

Greet.prototype = EE.prototype;

Greet.prototype.greet = function () {
    console.log('Hi');
}

var gg = new Greet();
console.log(gg.on());
console.log(gg.greeting)

console.log(Greet.prototype === EE.prototype)
